/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.diazfastfoodchatbot;
/**
 *  STI COLLEGE CUBAO
 *  DIAZ, KAISSER CHRISTOPHER O. BSIT 302
 *  DATA STRUCTURES AND ALGORITHMS (FINALS) TASK PERFORMANCE
 *  PROFESSOR: MR. BRAIAN CALATA
 */
import java.util.Scanner;
public class DiazFastFoodChatbot {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Fast Food Chain Chatbot!");
        System.out.println("How can I assist you today?");

        while (true) {
            System.out.print("User: ");
            String userInput = scanner.nextLine();
           
            String botResponse = getBotResponse(userInput);
            
            System.out.println("Bot: " + botResponse);
            
            if (userInput.equalsIgnoreCase("exit")) {
                System.out.println("Goodbye! Have a great day!");
                break;
            }
        }
        scanner.close();
    }
    private static String getBotResponse(String userInput) {
        switch (userInput.toLowerCase()) {
            case "menu":
                return "Our menu includes burgers, fries, drinks, and more. What would you like to order?";
            case "specials":
                return "Check out our daily specials on our website or ask me for details!";
            case "order":
                return "Great choice! Please specify your order details.";
            case "contact":
                return "You can reach us at diazkaisserfastfood@example.com or call us at 0910-723-8622.";
            case "exit":
                return "Thank you for chatting with us. Have a wonderful day!";
            default:
                return "I'm sorry, I didn't understand that. How can I help you?";
        }
    }
}
