/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.diaz_collegelist;

/**
 *
 * @author KAISSER CHRISTOPHER O. DIAZ      BSIT302
 */
public class Faculty extends Employee{
    boolean Status;
    //boolen method 
    boolean isRegular(boolean Status){
      
            return Status;
    }
    
}
