/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.diaz_collegelist;

/**
 *
 * @author KAISSER CHRISTOPHER O. DIAZ      BSIT302
 */
public class Employee extends Person{
    double Salary;
    String Department;
    //setter and getter method
    void setSalary(double Salary){
        this.Salary = Salary;
    }
    double getSalary(double Salary){
        return Salary;
    }
    void setDepartment(String Department){
        this.Department = Department;
    }
    String getDepartment(String Department){
        return Department;
    }
}