/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.diaz_collegelist;

/**
 *
 * @author KAISSER CHRISTOPHER O. DIAZ      BSIT302
 */
public class Student extends Person {
    String Program;
    int yearLevel;
    //setter getter methods
    void setProgram(String Program){
        this.Program = Program;
    }
    String getProgram(String Program){
        return Program;
    }
    void setYearLevel(int yearLevel){
        this.yearLevel = yearLevel;
    }
    int getYearLevel(int yearLevel){
        return yearLevel;
    }
}
