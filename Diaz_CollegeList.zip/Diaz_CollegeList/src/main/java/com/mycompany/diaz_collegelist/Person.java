/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.diaz_collegelist;

/**
 *
 * @author KAISSER CHRISTOPHER O. DIAZ      BSIT302
 */
public class Person {
    String Name;
    String contactNum;
    //setter and getter method
    void setName(String Name){
        this.Name = Name;
    }
    String getName(String Name){
        return Name;
    }
    void setContactNum(String contactNum){
        this.contactNum = contactNum;
    }
    String getContactNum(String contactNum){
        return contactNum;
    }
}