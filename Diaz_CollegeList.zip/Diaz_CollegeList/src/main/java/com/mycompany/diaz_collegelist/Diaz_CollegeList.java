/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.diaz_collegelist;

/**
 *
 * @author KAISSER CHRISTOPHER O. DIAZ      BSIT302
 */


import java.util.Scanner;
public class Diaz_CollegeList {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
        //instantiate object
        Employee employee = new Employee();
        Student student = new Student();        
        Faculty faculty = new Faculty();
        //input choice if employee, faculty, or student
        System.out.print("Press E for Employee, F for Faculty,or S for Student: ");
        String choice = sc.nextLine();
        
        
        if(choice.equalsIgnoreCase("E")){
            System.out.println("Type employee name, contact number, salary, and department.\nPress enter after every input");
            employee.setName(sc1.nextLine()); 
            employee.setContactNum(sc1.nextLine());
            employee.setSalary(sc1.nextDouble());           
            employee.setDepartment(sc2.nextLine());
            System.out.println("-------------------------------------");
            System.out.println("Name: "+employee.getName(employee.Name));
            System.out.println("Contact Number: "+employee.getContactNum(employee.contactNum));
            System.out.println("Salary: "+employee.getSalary(employee.Salary));
            System.out.println("Department: "+employee.getDepartment(employee.Department));
        }else if(choice.equalsIgnoreCase("S")){
            System.out.println("Type student name, contact number, program, and year level(1-4).+\nPress enter after every input");
            student.setName(sc1.nextLine());
            student.setContactNum(sc1.nextLine());
            student.setProgram(sc1.nextLine());
            student.setYearLevel(sc2.nextInt());
            System.out.println("-------------------------------------");
            System.out.println("Name: "+student.getName(student.Name));
            System.out.println("Contact Number: "+student.getContactNum(student.contactNum));
            System.out.println("Program: "+student.getProgram(student.Program));
            System.out.println("Year Level: "+student.getYearLevel(student.yearLevel));
        }else if(choice.equalsIgnoreCase("F")){    
            System.out.print("Are you regular/tenured? ");
            String Answer = sc1.nextLine();
            if(Answer.equalsIgnoreCase("Y")){
                faculty.Status = true;
                    
            }else if(Answer.equalsIgnoreCase("N")){
                faculty.Status = false;
            }
            System.out.println("Type employee name, contact number, salary, and department.\nPress enter after every input");
            faculty.isRegular(faculty.Status);
            faculty.setName(sc1.nextLine()); 
            faculty.setContactNum(sc1.nextLine());
            faculty.setSalary(sc1.nextDouble());           
            faculty.setDepartment(sc2.nextLine());
            System.out.println("-------------------------------------");
            System.out.println("Name: "+faculty.getName(faculty.Name));
            System.out.println("Contact Number: "+faculty.getContactNum(faculty.contactNum));
            System.out.println("Salary: "+faculty.getSalary(faculty.Salary));
            System.out.println("Department: "+faculty.getDepartment(faculty.Department));
            System.out.println("Status: "+faculty.Status);
            
        }else{
            System.out.println("Invalid input");
        }
    }
}
