/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.diazrunblooddata2;

/**
 *
 * @author KAISSER CHRISTOPHER O. DIAZ BSIT302
 */
import java.util.Scanner;
public class DiazRunBloodData2 {

    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
        System.out.print("Enter blood type of the patient: ");
        String input1 = scanner.nextLine();

        System.out.print("Enter the Rhesus factor (+ or -): ");
        String input2 = scanner.nextLine();

        DiazBloodData2 bd;
        
        if (input1.isEmpty() && input2.isEmpty()) {
            bd = new DiazBloodData2();
        } else {
            bd = new DiazBloodData2();
            bd.setBloodType(input1);
            bd.setRhFactor(input2);
        }

        bd.display();
    }
}
