/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.diazrunamountdue;

/**
 *
 * @author KYZER
 */
class DiazAmountDue {
    
// Overloaded method with one parameter (price)
    double computeAmountDue(double price) {
        double tax = price * 0.12;
        return price + tax;
    }

    // Overloaded method with two parameters (price and quantity)
    double computeAmountDue(double price, int quantity) {
        double total = price * quantity;
        double tax = total * 0.12;
        return total + tax;
    }

    // Overloaded method with three parameters (price, quantity, and discount amount)
    double computeAmountDue(double price, int quantity, double discount) {
        double total = (price * quantity) - discount;
        double tax = total * 0.12;
        return total + tax;
    }
}

