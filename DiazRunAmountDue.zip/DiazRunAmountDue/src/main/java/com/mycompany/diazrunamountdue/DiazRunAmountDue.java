/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.diazrunamountdue;

/**
 *
 * @author KYZER
 */
import java.util.Scanner;
public class DiazRunAmountDue {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        DiazAmountDue due = new DiazAmountDue();

        System.out.println("Press any of the following then enter values separated by spaces:");
        System.out.println("1 - Price only");
        System.out.println("2 - Price and quantity");
        System.out.println("3 - Price, quantity, and discount amount");
        System.out.println("----------------------------------------");
        System.out.print("Enter your choice: ");

        int choice = s.nextInt();
        double price, discount = 0;
        int quantity = 1;

        if (choice >= 1 && choice <= 3) {
            System.out.print("Enter values separated by spaces: ");
            price = s.nextDouble();

            if (choice >= 2) {
                quantity = s.nextInt();
            }
            if (choice == 3) {
                discount = s.nextDouble();
            }
            double amountDue = due.computeAmountDue(price, quantity, discount);
            System.out.println("Amount due is " + amountDue);
        } else {
            System.out.println("Invalid input. Please enter 1, 2, or 3 only.");
        }
        s.close();
    }
}
