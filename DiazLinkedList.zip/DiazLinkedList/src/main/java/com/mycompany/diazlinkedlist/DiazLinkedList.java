/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.diazlinkedlist;

import java.util.LinkedList;

/**
 *
 * @author KYZER
 */
public class DiazLinkedList {

    public static void main(String[] args) {
        LinkedList<String> songs = new LinkedList<>();
        LinkedList<String> artists = new LinkedList<>();
        LinkedList<String> playlist = new LinkedList<>();

        songs.add("Gusto");
        songs.add("Save Your Tears");
        songs.add("Starboy");
        songs.add("Leaves");
        songs.add("Circles");

        artists.add("Zack Tabudlo");
        artists.add("The Weeknd");
        artists.add("The Weeknd");
        artists.add("Ben & Ben");
        artists.add("Post Malone");

        for (int i = 0; i < songs.size(); i++) {
            String song = songs.get(i);
            String artist = artists.get(i);
            String playlistEntry = song + " - " + artist;
            playlist.add(playlistEntry);
        }

        System.out.println(songs);
        System.out.println(artists);
        for (String entry : playlist) {
            System.out.println(entry);
        }
    }
}
