/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.htmltree;

/**
 *
 * @author KAISSER CHRISTOPHER O. DIAZ   BSIT 302
 */
import java.awt.List;
import java.util.Collections;
import javax.swing.JFrame;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class HtmlTree extends JFrame{
    JTree tree;
    public HtmlTree(){
        DefaultMutableTreeNode html = new DefaultMutableTreeNode("html");
        DefaultMutableTreeNode head = new DefaultMutableTreeNode("head");
        DefaultMutableTreeNode body = new DefaultMutableTreeNode("body");
        DefaultMutableTreeNode meta = new DefaultMutableTreeNode("meta");
        DefaultMutableTreeNode title = new DefaultMutableTreeNode("title");
        DefaultMutableTreeNode ul = new DefaultMutableTreeNode("ul");
        DefaultMutableTreeNode h1 = new DefaultMutableTreeNode("h1");
        DefaultMutableTreeNode h2 = new DefaultMutableTreeNode("h2");
        DefaultMutableTreeNode li = new DefaultMutableTreeNode("li");
        DefaultMutableTreeNode Ii = new DefaultMutableTreeNode("li");
        DefaultMutableTreeNode a = new DefaultMutableTreeNode("a");
        html.add(head);
        html.add(body);
        head.add(meta);
        head.add(title);
        body.add(ul);
        body.add(h1);
        body.add(h2);
        h2.add(a);
        ul.add(li);
        ul.add(Ii);
        tree = new JTree(html);
        add(tree);
        this.setTitle("JTree Example");
        this.setSize(300,300);
        this.setVisible(true);


System.out.println ("The root node is: "+ meta.getRoot()); 
System.out.println ("The parent nodes are: "+head.getParent()+","+ ul.getParent()+","+ ul.getParent()+","+h1.getParent() +","+li.getParent()+","+Ii.getParent()); 
System.out.println ("The siblings are: "+Collections.list(html.children())+""+Collections.list(head.children()) +""+Collections.list(body.children())+""+Collections.list(ul.children()));
System.out.println ("""
                    The one level subtrees: 
                    """+html+"-"+Collections.list(html.children())); 
System.out.println (head+"-"+Collections.list(head.children())); 
System.out.println (body+"-"+Collections.list(body.children())); 
System.out.println (ul+"-"+Collections.list(ul.children())); 
System.out.println (h2+"-"+Collections.list(h2.children())); 
System.out.println ("""
                    Nodes per level: 
                    Level """+ html.getLevel() +"-"+html.getRoot()); 
System.out.println ("Level "+ head.getLevel()+"-"+body+","+body); 
System.out.println ("Level "+ meta.getLevel() +"-"+meta+","+title+","+ul+","+h1+","+h2); 
System.out.println ("Level "+ li.getLevel()+"-"+li+","+Ii+","+Ii); 
System.out.println ("Depth: "+html.getDepth()); 
System.out.println ("""
                    The degree of each one-level subtree: 
                    Subtree """+html+"-"+html.getChildCount()); 
System.out.println ("Subtree "+head+"-"+head.getChildCount()); 
System.out.println ("Subtree "+body+"-"+head.getChildCount()); 
System.out.println ("Subtree "+ul+"-"+ul.getChildCount()); 
System.out.println ("Subtree "+h2+"-"+h2.getChildCount());
java.util.List bfe = Collections.list(html.breadthFirstEnumeration()); 
System.out.println ("List of nodes based on breadth-first: "+bfe); 
java.util.List pro = Collections.list(html.preorderEnumeration()); 
System.out.println ("List of nodes based on preorder: "+pro); 
java.util.List po = Collections.list(html.postorderEnumeration()); 
System.out.println ("List of nodes based on postorder: "+po); 

    }

 

    public static void main(String[] args) {
       new HtmlTree();


    }
}
