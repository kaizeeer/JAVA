/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.diaztp1;

/**
 *
 * @author KAISSER CHRISTOPHER O. DIAZ  BSIT302
 */
import java.util.LinkedList;

import java.util.Queue;

import java.util.Scanner;

import java.util.Stack;

public class DIAZTP1

{

 public static void main(String[] args)

{

  Stack<String> s=new Stack<>();

  Queue<String> q=new LinkedList<>();

  Scanner sc=new Scanner(System.in);

  System.out.println("Enter four book titles.");

  for(int i=1;i<=4;i++) { //i from 1 to 4

   System.out.print("Book "+i+": ");

   s.add(sc.nextLine()); //push the user input to Stack

  }

  while(!s.isEmpty()) { //enters loop if stack is not empty

   q.add(s.pop()); //pop from stack and insert to queue

  }

  System.out.println("New order of books: "+q); //print queue

 }

}
