/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author KYZER
 */

import java.util.Scanner;

public class RunSavingsAccount {
//DIAZ, KAISSER CHRISTOPHER O. BSIT302//
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SavingsAccount savings = new SavingsAccount();

        System.out.print("Enter the interest rate: ");
        double interestRate = scanner.nextDouble();
        SavingsAccount.setInterestRate(interestRate);

        System.out.print("Enter deposit amount: ");
    double initialDeposit = scanner.nextDouble();
    savings.deposit(initialDeposit);
 
                System.out.println("Your balance is " + savings.getBalance());
    
       while (true) {
        System.out.print("Press D to deposit, W to withdraw, or Q to quit: ");
        String choice = scanner.next().toUpperCase();

        if (choice.equals("Q")) {
            break;
        } else if (choice.equals("D")) {
            System.out.print("Enter deposit amount: ");
            double depositAmount = scanner.nextDouble();
            savings.deposit(depositAmount);
        } else if (choice.equals("W")) {
            System.out.print("Enter withdrawal amount: ");
            double withdrawAmount = scanner.nextDouble();
            double withdrawn = savings.withdraw(withdrawAmount);
            System.out.println("Withdrawn: " + withdrawn);
            System.out.println("Your new balance is " + savings.getBalance());         
        }
//DIAZ, KAISSER CHRISTOPHER O. BSIT302//
      
        if (savings.getBalance() > 1000) {
            savings.addInterest();
             SavingsAccount.showBalance(savings);
             break;
}
       }
    }
}
