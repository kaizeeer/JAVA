/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author KAISSER CHRISTOPHER O. DIAZ BSIT302
 */
public class DiazBloodData2 {
    private String bloodType; 
    private String rhFactor; 

    public DiazBloodData2() {
        bloodType = "O";
        rhFactor = "+";
    }

    public DiazBloodData2(String bt, String rh) {
        bloodType = bt;
        rhFactor = rh;
    }

    public void display() {
        System.out.println(getBloodType() + getRhFactor() + " is added to the blood bank.");
    }

    //Getter 
    public String getBloodType() {
        return bloodType;
    }
    
    public String getRhFactor() {
        return rhFactor;
    }
    
    //Setter
    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public void setRhFactor(String rhFactor) {
        this.rhFactor = rhFactor;
    }
}